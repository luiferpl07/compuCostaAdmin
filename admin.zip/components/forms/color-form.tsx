"use client";

import { useState } from "react";
import { useForm } from "react-hook-form";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Separator } from "@/components/ui/separator";
import { Heading } from "@/components/ui/heading";
import { zodResolver } from "@hookform/resolvers/zod";
import { useToast } from "@/hooks/use-toast";
import axios from "axios";
import * as z from "zod";

const formSchema = z.object({
  nombre: z.string().min(1, "El nombre es requerido"),
  codigoHex: z
    .string()
    .min(1, "El código hexadecimal es requerido")
    .regex(/^#([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})$/, "Código hexadecimal inválido"),
});

type ColorFormValues = z.infer<typeof formSchema>;

interface ColorFormProps {
  initialData?: {
    id: number;
    nombre: string;
    codigoHex: string;
  } | null;
}

export const ColorForm: React.FC<ColorFormProps> = ({ initialData }) => {
  const [loading, setLoading] = useState(false);
  const router = useRouter();
  const { toast } = useToast();
  
  const form = useForm<ColorFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      nombre: initialData?.nombre || "",
      codigoHex: initialData?.codigoHex || "#",
    },
  });

  const onSubmit = async (data: ColorFormValues) => {
    try {
      setLoading(true);
      if (initialData) {
        await axios.patch(`/api/colors/${initialData.id}`, data);
      } else {
        await axios.post("/api/colors", data);
      }
      router.refresh();
      router.push("/colors");
      toast({
        title: "¡Éxito!",
        description: `Color ${initialData ? "actualizado" : "creado"} correctamente.`,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Algo salió mal.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <div className="flex items-center justify-between">
        <Heading
          title={initialData ? "Editar color" : "Crear color"}
          description={initialData ? "Edita un color existente" : "Agrega un nuevo color"}
        />
      </div>
      <Separator />
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 w-full">
          <div className="grid grid-cols-3 gap-8">
            <FormField
              control={form.control}
              name="nombre"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Nombre</FormLabel>
                  <FormControl>
                    <Input disabled={loading} placeholder="Classic Blue" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="codigoHex"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Código Hexadecimal</FormLabel>
                  <FormControl>
                    <div className="flex gap-4">
                      <Input disabled={loading} placeholder="#0047AB" {...field} />
                      <div
                        className="w-10 h-10 rounded-full border"
                        style={{ backgroundColor: field.value }}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>
          <Button disabled={loading} type="submit">
            {initialData ? "Guardar cambios" : "Crear"}
          </Button>
        </form>
      </Form>
    </>
  );
};

export default ColorForm;