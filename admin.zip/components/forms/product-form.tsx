"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { toast } from "sonner";
import { ArrowLeft, X } from "lucide-react";
import { slugify } from "@/lib/utils"; // Asumiendo que tienes una función de utilidad para slugify

interface Category {
  id: number;
  nombre: string;
}

interface Color {
  id: number;
  nombre: string;
  codigoHex: string;
}

const formSchema = z.object({
  idProductoERP: z.string().min(1, "ERP ID is required"),
  nombre: z.string().min(1, "Name is required"),
  precio: z.string().min(1, "Price is required"),
  descripcionLarga: z.string().optional(),
  descripcionCorta: z.string().optional(),
  metaTitulo: z.string().optional(),
  metaDescripcion: z.string().optional(),
  slug: z.string().min(1, "Slug is required"),
  destacado: z.boolean().default(false),
  categoriaIds: z.array(z.number()),
  colorIds: z.array(z.number()),
  imagenes: z.array(z.object({
    url: z.string(),
    altText: z.string().optional(),
    orden: z.number(),
    esPrincipal: z.boolean()
  }))
});

type ProductFormValues = z.infer<typeof formSchema>;

interface ProductFormProps {
  initialData?: ProductFormValues;
}

export default function ProductForm({ initialData }: ProductFormProps) {
  const [loading, setLoading] = useState(false);
  const [categories, setCategories] = useState<Category[]>([]);
  const [colors, setColors] = useState<Color[]>([]);
  const router = useRouter();

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: initialData || {
      idProductoERP: "",
      nombre: "",
      precio: "",
      descripcionLarga: "",
      descripcionCorta: "",
      metaTitulo: "",
      metaDescripcion: "",
      slug: "",
      destacado: false,
      categoriaIds: [],
      colorIds: [],
      imagenes: []
    },
  });

  // Generar slug automáticamente cuando cambia el nombre
  useEffect(() => {
    const subscription = form.watch((value, { name }) => {
      if (name === "nombre") {
        form.setValue("slug", slugify(value.nombre || ""));
      }
    });
    return () => subscription.unsubscribe();
  }, [form]);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [categoriesRes, colorsRes] = await Promise.all([
          fetch("/api/categories"),
          fetch("/api/colors")
        ]);
        
        const categoriesData = await categoriesRes.json();
        const colorsData = await colorsRes.json();
        
        setCategories(categoriesData);
        setColors(colorsData);
      } catch (error) {
        toast.error("Error loading form data");
      }
    };

    fetchData();
  }, []);

  const onSubmit = async (data: ProductFormValues) => {
    try {
      setLoading(true);
      const response = await fetch("/api/products", {
        method: initialData ? "PUT" : "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          ...data,
          precio: parseFloat(data.precio),
        }),
      });

      if (!response.ok) {
        throw new Error("Something went wrong");
      }

      toast.success(initialData ? "Product updated successfully" : "Product created successfully");
      router.push("/products");
      router.refresh();
    } catch (error) {
      toast.error("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    // Implementar lógica de carga de imágenes
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Button variant="ghost" onClick={() => router.back()}>
            <ArrowLeft className="h-4 w-4" />
          </Button>
          <h2 className="text-3xl font-bold tracking-tight">
            {initialData ? "Edit Product" : "Create Product"}
          </h2>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Product Information</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="idProductoERP"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>ERP ID</FormLabel>
                      <FormControl>
                        <Input placeholder="Product ERP ID" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nombre"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Product name" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="descripcionCorta"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Short Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Brief product description" 
                          {...field}
                          rows={3}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="descripcionLarga"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Long Description</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Detailed product description" 
                          {...field}
                          rows={3}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="metaTitulo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meta Title</FormLabel>
                      <FormControl>
                        <Input placeholder="SEO meta title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="metaDescripcion"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Meta Description</FormLabel>
                      <FormControl>
                        <Input placeholder="SEO meta description" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="precio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Price</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          step="0.01"
                          placeholder="0.00" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="slug"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Slug</FormLabel>
                      <FormControl>
                        <Input placeholder="product-slug" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="categoriaIds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Categories</FormLabel>
                    <Select 
                      onValueChange={(value) => {
                        const currentIds = field.value;
                        const newValue = parseInt(value);
                        if (!currentIds.includes(newValue)) {
                          field.onChange([...currentIds, newValue]);
                        }
                      }}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select categories" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem 
                            key={category.id} 
                            value={category.id.toString()}
                          >
                            {category.nombre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {field.value.map((categoryId) => {
                        const category = categories.find(c => c.id === categoryId);
                        return (
                          <Badge key={categoryId} variant="secondary">
                            {category?.nombre}
                            <button
                              type="button"
                              onClick={() => {
                                field.onChange(field.value.filter(id => id !== categoryId));
                              }}
                              className="ml-1"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        );
                      })}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="colorIds"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Colors</FormLabel>
                    <Select 
                      onValueChange={(value) => {
                        const currentIds = field.value;
                        const newValue = parseInt(value);
                        if (!currentIds.includes(newValue)) {
                          field.onChange([...currentIds, newValue]);
                        }
                      }}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select colors" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {colors.map((color) => (
                          <SelectItem 
                            key={color.id} 
                            value={color.id.toString()}
                          >
                            <div className="flex items-center gap-2">
                              <div 
                                className="w-4 h-4 rounded-full" 
                                style={{ backgroundColor: color.codigoHex }}
                              />
                              {color.nombre}
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <div className="flex flex-wrap gap-2 mt-2">
                      {field.value.map((colorId) => {
                        const color = colors.find(c => c.id === colorId);
                        return (
                          <Badge 
                            key={colorId} 
                            variant="secondary"
                            style={{ 
                              backgroundColor: color?.codigoHex,
                              color: '#fff'
                            }}
                          >
                            {color?.nombre}
                            <button
                              type="button"
                              onClick={() => {
                                field.onChange(field.value.filter(id => id !== colorId));
                              }}
                              className="ml-1"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </Badge>
                        );
                      })}
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="destacado"
                render={({ field }) => (
                  <FormItem className="flex items-center justify-between rounded-lg border p-4">
                    <div className="space-y-0.5">
                      <FormLabel className="text-base">Featured</FormLabel>
                    </div>
                    <FormControl>
                      <Switch
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    </FormControl>
                  </FormItem>
                )}
              />

              <div className="flex justify-end">
                <Button disabled={loading} type="submit">
                  {initialData ? "Save changes" : "Create"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}