import ProductForm from "@/components/forms/product-form";

export default function NewProductPage() {
  return <ProductForm />;
}