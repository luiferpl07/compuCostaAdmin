import BannerForm from "@/components/forms/banner-form";

export default function NewBannerPage() {
  return <BannerForm />;
}