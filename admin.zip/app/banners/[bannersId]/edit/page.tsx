import BannerForm from "@/components/forms/banner-form";

interface Props {
  params: {
    bannerId: string;
  };
}

export default async function EditBannerPage({ params }: Props) {
  // Aquí puedes obtener los datos del banner para editar
  const banner = await fetch(`/api/banners/${params.bannerId}`).then(res => res.json());
  
  return <BannerForm initialData={banner} />;
}