import { NextResponse } from 'next/server';
import prismadb from "@/lib/prismadb";

export async function PUT(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    const data = await request.json();
    const category = await prismadb.categoria.update({
      where: { id: parseInt(params.id) },
      data: {
        nombre: data.nombre,
        descripcion: data.descripcion,
        slug: data.slug,
        imagen: data.imagen,
      },
    });
    return NextResponse.json(category);
  } catch (error) {
    return NextResponse.json(
      { error: 'Error updating category' },
      { status: 500 }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: { id: string } }
) {
  try {
    await prismadb.categoria.delete({
      where: { id: parseInt(params.id) },
    });
    return NextResponse.json({ message: 'Category deleted successfully' });
  } catch (error) {
    return NextResponse.json(
      { error: 'Error deleting category' },
      { status: 500 }
    );
  }
}