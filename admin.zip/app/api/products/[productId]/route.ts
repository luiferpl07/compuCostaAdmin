// app/api/products/[productId]/route.ts
import { NextResponse } from "next/server";
import prismadb from "@/lib/prismadb";

export async function GET(
  req: Request,
  { params }: { params: { productId: string } }
) {
  try {
    if (!params.productId) {
      return new NextResponse("Product id is required", { status: 400 });
    }

    const product = await prismadb.product.findUnique({
      where: {
        id: params.productId
      },
      include: {
        category: true,
        color: true
      }
    });

    return NextResponse.json(product);
  } catch (error) {
    console.error('[PRODUCT_GET]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: { productId: string } }
) {
  try {
    const body = await req.json();
    const { 
      name, 
      description, 
      price, 
      images, 
      stock, 
      categoryId, 
      colorId,
      isActive 
    } = body;

    if (!params.productId) {
      return new NextResponse("Product id is required", { status: 400 });
    }

    // Verificar si el producto existe
    const existingProduct = await prismadb.product.findUnique({
      where: { id: params.productId }
    });

    if (!existingProduct) {
      return new NextResponse("Product not found", { status: 404 });
    }

    const updatedProduct = await prismadb.product.update({
      where: {
        id: params.productId
      },
      data: {
        name,
        description,
        price: price ? parseFloat(price.toString()) : undefined,
        images,
        stock,
        categoryId,
        colorId,
        isActive
      },
      include: {
        category: true,
        color: true
      }
    });

    return NextResponse.json(updatedProduct);
  } catch (error) {
    console.error('[PRODUCT_PATCH]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { productId: string } }
) {
  try {
    if (!params.productId) {
      return new NextResponse("Product id is required", { status: 400 });
    }

    const product = await prismadb.product.delete({
      where: {
        id: params.productId
      }
    });

    return NextResponse.json(product);
  } catch (error) {
    console.error('[PRODUCT_DELETE]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
}