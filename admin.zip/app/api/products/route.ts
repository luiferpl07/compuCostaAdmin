// app/api/products/route.ts
import { NextResponse } from "next/server";
import prismadb from "@/lib/prismadb";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { 
      name, 
      description, 
      price, 
      images, 
      stock, 
      categoryId, 
      colorId,
      isActive 
    } = body;

    if (!name || !description || !price || !images || !categoryId || !colorId) {
      return new NextResponse("Missing required fields", { status: 400 });
    }

    // Verificar si la categoría y el color existen
    const category = await prismadb.category.findUnique({
      where: { id: categoryId }
    });

    const color = await prismadb.color.findUnique({
      where: { id: colorId }
    });

    if (!category || !color) {
      return new NextResponse("Invalid category or color", { status: 400 });
    }

    const product = await prismadb.product.create({
      data: {
        name,
        description,
        price: parseFloat(price.toString()),
        images,
        stock: stock || 0,
        categoryId,
        colorId,
        isActive: isActive ?? true,
      },
    });

    return NextResponse.json(product);
  } catch (error) {
    console.error('[PRODUCTS_POST]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const categoryId = searchParams.get('categoryId');
    const colorId = searchParams.get('colorId');

    let whereClause = {};

    if (categoryId) {
      whereClause = {
        ...whereClause,
        categoryId
      };
    }

    if (colorId) {
      whereClause = {
        ...whereClause,
        colorId
      };
    }

    const products = await prismadb.product.findMany({
      where: whereClause,
      include: {
        category: true,
        color: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    return NextResponse.json(products);
  } catch (error) {
    console.error('[PRODUCTS_GET]', error);
    return new NextResponse("Internal error", { status: 500 });
  }
}