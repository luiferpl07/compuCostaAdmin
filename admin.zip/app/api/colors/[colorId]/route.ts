import { NextResponse } from "next/server";
import prismadb from "@/lib/prismadb";

export async function GET(
  req: Request,
  { params }: { params: { colorId: string } }
) {
  try {
    const color = await prismadb.color.findUnique({
      where: {
        id: parseInt(params.colorId)
      }
    });
  
    return NextResponse.json(color);
  } catch (error) {
    console.log('[COLOR_GET]', error);
    return new NextResponse("Error interno", { status: 500 });
  }
}

export async function PATCH(
  req: Request,
  { params }: { params: { colorId: string } }
) {
  try {
    const body = await req.json();
    const { nombre, codigoHex } = body;

    if (!nombre || !codigoHex) {
      return new NextResponse("Faltan datos requeridos", { status: 400 });
    }

    const color = await prismadb.color.update({
      where: {
        id: parseInt(params.colorId)
      },
      data: {
        nombre,
        codigoHex
      }
    });
  
    return NextResponse.json(color);
  } catch (error) {
    console.log('[COLOR_PATCH]', error);
    return new NextResponse("Error interno", { status: 500 });
  }
}

export async function DELETE(
  req: Request,
  { params }: { params: { colorId: string } }
) {
  try {
    const color = await prismadb.color.delete({
      where: {
        id: parseInt(params.colorId)
      }
    });
  
    return NextResponse.json(color);
  } catch (error) {
    console.log('[COLOR_DELETE]', error);
    return new NextResponse("Error interno", { status: 500 });
  }
}