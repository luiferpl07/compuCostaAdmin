import { NextResponse } from "next/server";
import prismadb from "@/lib/prismadb";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { nombre, codigoHex } = body;

    if (!nombre || !codigoHex) {
      return new NextResponse("Faltan datos requeridos", { status: 400 });
    }

    const color = await prismadb.color.create({
      data: {
        nombre,
        codigoHex,
      }
    });

    return NextResponse.json(color);
  } catch (error) {
    console.log('[COLORS_POST]', error);
    return new NextResponse("Error interno", { status: 500 });
  }
}

export async function GET() {
  try {
    const colors = await prismadb.color.findMany({
      orderBy: {
        nombre: 'asc'
      }
    });

    return NextResponse.json(colors);
  } catch (error) {
    console.log('[COLORS_GET]', error);
    return new NextResponse("Error interno", { status: 500 });
  }
}