import CategoryForm from "@/components/forms/category-form";


export default function NewcategoriesPage() {
  return <CategoryForm/>;
}